#!/bin/bash
# 招标信息抓取脚本

cd "$(dirname "$0")"

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo "错误：未找到 Python3"
    exit 1
fi

# 安装依赖（如果需要）
echo "检查依赖..."
pip3 install -q -r requirements.txt 2>/dev/null || pip install -q -r requirements.txt 2>/dev/null

# 检查Playwright浏览器
python3 -c "from playwright.sync_api import sync_playwright; sync_playwright().start().chromium.launch()" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "安装Playwright浏览器..."
    python3 -m playwright install chromium
fi

# 运行抓取脚本
echo "开始抓取招标信息..."
python3 bidding_notifier.py
